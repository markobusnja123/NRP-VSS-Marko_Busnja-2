import sqlite3
from Utils.paths import DATA_DIR

DB_FILE = DATA_DIR / "app.db"


def get_connection():
    DATA_DIR.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_FILE)
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # tabela tasks (že obstaja)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            priority TEXT NOT NULL,
            priority_rank INTEGER NOT NULL,
            due TEXT NOT NULL
        )
        """
    )

    # nova tabela focus_sessions
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS focus_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT NOT NULL,
            end_time TEXT,
            duration_seconds INTEGER,
            session_index INTEGER DEFAULT 1
        )
        """
    )
    
    # Migracija: ce stolpec session_index se ne obstaja
    try:
        cur.execute("ALTER TABLE focus_sessions ADD COLUMN session_index INTEGER DEFAULT 1")
    except sqlite3.OperationalError:
        # Stolpec verjetno ze obstaja
        pass

    conn.commit()
    conn.close()
