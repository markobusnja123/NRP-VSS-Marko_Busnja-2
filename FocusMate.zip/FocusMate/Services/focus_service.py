from Services.db_service import get_connection
from datetime import datetime


def start_session(session_index=1):
    """Ustvari novo fokusno sejo z začetnim časom in indeksom seje, vrne session_id."""
    conn = get_connection()
    cur = conn.cursor()
    start_time = datetime.now().isoformat()
    cur.execute(
        "INSERT INTO focus_sessions (start_time, session_index) VALUES (?, ?)",
        (start_time, session_index)
    )
    conn.commit()
    session_id = cur.lastrowid
    conn.close()
    return session_id, start_time


def get_next_session_index():
    """Vrne naslednji zaporedni index seje za danes (npr. 1, 2, 3...)."""
    conn = get_connection()
    cur = conn.cursor()
    today_str = datetime.now().strftime("%Y-%m-%d")
    
    # Poisci max session_index za danes
    cur.execute(
        "SELECT MAX(session_index) FROM focus_sessions WHERE substr(start_time, 1, 10) = ?",
        (today_str,)
    )
    row = cur.fetchone()
    conn.close()
    
    if row and row[0]:
        return row[0]
    else:
        # Ce se ni sej danes, preverimo, ce sploh obstaja kaksna seja, da ne resetiramo po pomoti
        # Ampak zahteva je reset daily, tako da return 1 je prav.
        # Edino pazi: ce uporabnik nadaljuje "Current Session", ne smemo povecati indexa samo zato.
        # Ta funkcija vrne INDEX ZADNJE SEJE. UI se mora odlociti, a bo uporabil ta index (nadaljevanje) ali index+1 (nova).
        # Po navodilih: "Start with first session... timer appears... after 45m... button saying next session"
        # To pomeni: ko je Timer running/paused, smo v index X. Ko timer pride do 0, smo koncali X. Gumb "Next" gre na X+1.
        
        # Poglejmo to drugace: Vrni index, ki ga moramo prikazati.
        # Ce je zadnja seja danes koncana (ima duration), potem je naslednji index = max + 1.
        # Ce zadnja seja NI koncana (duration is NULL - crash?), potem bi jo morda morali nadaljevati, ampak start_session ustvari novo vrstico.
        # Predpostavimo preprost flow: UI vodi index. Ta funkcija samo pove, kje smo ostali.
        return 1
        
def get_current_max_index():
    """Vrne max index danes."""
    conn = get_connection()
    cur = conn.cursor()
    today_str = datetime.now().strftime("%Y-%m-%d")
    cur.execute(
        "SELECT MAX(session_index) FROM focus_sessions WHERE substr(start_time, 1, 10) = ?",
        (today_str,)
    )
    row = cur.fetchone()
    conn.close()
    if row and row[0]:
        return row[0]
    return 0


def end_session(session_id):
    """Konča sejo: zapiše end_time in duration_seconds."""
    conn = get_connection()
    cur = conn.cursor()
    
    # preberi start_time
    cur.execute("SELECT start_time FROM focus_sessions WHERE id = ?", (session_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return
    
    start_time_str = row[0]
    start_dt = datetime.fromisoformat(start_time_str)
    end_dt = datetime.now()
    duration = int((end_dt - start_dt).total_seconds())
    
    cur.execute(
        "UPDATE focus_sessions SET end_time = ?, duration_seconds = ? WHERE id = ?",
        (end_dt.isoformat(), duration, session_id)
    )
    conn.commit()
    conn.close()
    return duration


def load_sessions():
    """Naloži vse seje (za analitiko)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, start_time, end_time, duration_seconds FROM focus_sessions ORDER BY start_time DESC"
    )
    rows = cur.fetchall()
    conn.close()
    
    sessions = []
    for row in rows:
        sid, start, end, duration = row
        sessions.append({
            "id": sid,
            "start_time": start,
            "end_time": end,
            "duration_seconds": duration
        })
    return sessions


def get_today_total_seconds():
    """Vrne skupno stevilo sekund fokusa za angleski dan."""
    conn = get_connection()
    cur = conn.cursor()
    
    # SQLite 'date("now", "localtime")' will give used YYYY-MM-DD in local time
    # Assuming start_time is stored as ISO string, likely "YYYY-MM-DDTHH:MM:SS..."
    # We can match substr(start_time, 1, 10) == date('now') if we trust server time match
    # OR cleaner: calculate in python.
    
    today_str = datetime.now().strftime("%Y-%m-%d")
    
    cur.execute(
        "SELECT duration_seconds FROM focus_sessions WHERE substr(start_time, 1, 10) = ?",
        (today_str,)
    )
    rows = cur.fetchall()
    conn.close()
    
    total = 0
    for row in rows:
        if row[0]: # duration_seconds is not Null
            total += row[0]
            
    return total


def get_history_stats():
    """Vrne statistiko po dnevih: {date_str: total_seconds}."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT substr(start_time, 1, 10) as day, sum(duration_seconds)
        FROM focus_sessions
        WHERE duration_seconds IS NOT NULL
        GROUP BY day
        ORDER BY day DESC
        """
    )
    rows = cur.fetchall()
    conn.close()
    
    stats = []
    for row in rows:
        stats.append({"date": row[0], "total_seconds": row[1]})
        
    return stats


def get_detailed_history():
    """
    Vrne zgodovino, grupirano po sejah (Datum, Index seje, Skupno trajanje).
    Seznam slovarjev: [{'date': '...', 'session_index': 1, 'total_seconds': 1800}, ...]
    """
    conn = get_connection()
    cur = conn.cursor()
    # Group rows by (date, session_index)
    cur.execute(
        """
        SELECT substr(start_time, 1, 10) as day, session_index, sum(duration_seconds)
        FROM focus_sessions
        WHERE duration_seconds IS NOT NULL
        GROUP BY day, session_index
        ORDER BY day DESC, session_index DESC
        """
    )
    rows = cur.fetchall()
    conn.close()
    
    history = []
    for row in rows:
        history.append({
            "date": row[0],
            "session_index": row[1],
            "total_seconds": row[2]
        })
    return history


def reset_history():
    """Izbrise celotno zgodovino (truncate table)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM focus_sessions")
    conn.commit()
    conn.close()
