"""
groq_service.py – Calls Groq API in a background thread.
"""

import os
from PySide6.QtCore import QThread, Signal

# Path to the API key file
_API_KEY_PATH = os.path.join(os.path.dirname(__file__), "..", "groq_api.txt")

SYSTEM_PROMPT = (
    "You are a friendly focus coach for students. "
    "The student is feeling stuck and overwhelmed. "
    "Give a warm, encouraging response that:\n"
    "1. Tells them to take a short break (2-5 minutes).\n"
    "2. Lists exactly 5 simple, easy brain-reset tasks they can do right now "
    "(e.g. drink water, stretch, take deep breaths, look out the window, etc.).\n"
    "Format your response clearly with a short intro paragraph and then a numbered list. "
    "Keep the whole response under 150 words. Be uplifting and kind."
)


def _read_api_key() -> str:
    with open(_API_KEY_PATH, "r", encoding="utf-8") as f:
        return f.read().strip()


class GroqWorker(QThread):
    """Background thread that calls the Groq API and emits the result."""

    result_ready = Signal(str)   # emitted with the AI text
    error_occurred = Signal(str) # emitted if something goes wrong

    def run(self):
        try:
            from groq import Groq  # pip install groq
            api_key = _read_api_key()
            client = Groq(api_key=api_key)

            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": "I'm stuck. Help me take a break."},
                ],
                max_tokens=300,
                temperature=0.8,
            )

            text = response.choices[0].message.content.strip()
            self.result_ready.emit(text)

        except Exception as e:
            self.error_occurred.emit(f"Error: {e}")
