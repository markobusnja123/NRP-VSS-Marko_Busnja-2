from Services.db_service import get_connection


def load_tasks():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, title, priority, priority_rank, due FROM tasks "
        "ORDER BY priority_rank, due"
    )
    rows = cur.fetchall()
    conn.close()

    tasks = []
    for row in rows:
        task_id, title, priority, priority_rank, due = row
        tasks.append(
            {
                "id": task_id,
                "title": title,
                "priority": priority,
                "priority_rank": priority_rank,
                "due": due,
            }
        )
    return tasks


def add_task(title, priority, priority_rank, due):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO tasks (title, priority, priority_rank, due) "
        "VALUES (?, ?, ?, ?)",
        (title, priority, priority_rank, due),
    )
    conn.commit()
    task_id = cur.lastrowid
    conn.close()
    return task_id


def update_task(task):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """
        UPDATE tasks
        SET title = ?, priority = ?, priority_rank = ?, due = ?
        WHERE id = ?
        """,
        (task["title"], task["priority"], task["priority_rank"], task["due"], task["id"]),
    )
    conn.commit()
    conn.close()


def delete_task(task_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
