"""
chatbot_tab.py – Full AI chat interface for FocusMate.

[AI DODATEK OBRAZLOŽITEV]:
Ta datoteka predstavlja celoten "AI" del aplikacije. Razdeljena je na 3 pomembne dele:
1. _GroqWorker: Se zažene v ozadju (v lastnem 'Threadu'), tako da klic API-ja ne
   zmrzne celotne aplikacije medtem ko čaka na odgovor. Prebere ključ iz 'groq_api.txt'.
2. SYSTEM_PROMPT: Navodilo v angleščini, ki umetni inteligenci (Llama) pove, 
   kako naj se obnaša (kot študijski trener in naj predlaga preproste naloge).
3. ChatbotTab: Sam grafični vmesnik (UI), ki vsebuje oblačke s sporočili, 
   polje za vnos teksta in se samodejno pomika navzdol.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QTextEdit, QLineEdit, QPushButton, QScrollArea,
    QSizePolicy, QFrame
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QKeyEvent
import os

# ── Groq worker ─────────────────────────────────────────────────────────────

_API_KEY_PATH = os.path.join(os.path.dirname(__file__), "..", "groq_api.txt")

SYSTEM_PROMPT = (
    "You are a warm, friendly focus coach and study buddy for students. "
    "You help them stay motivated, overcome mental blocks, and take productive breaks. "
    "When they say they are stuck, suggest a short break and give 5 simple reset tasks. "
    "For all other messages, be supportive, concise, and encouraging. "
    "Keep responses under 120 words unless asked for more detail."
)


class _GroqWorker(QThread):
    result_ready   = Signal(str)
    error_occurred = Signal(str)

    def __init__(self, history: list):
        super().__init__()
        self._history = history  # list of {"role": ..., "content": ...}

    def run(self):
        try:
            from groq import Groq
            with open(_API_KEY_PATH, "r", encoding="utf-8") as f:
                api_key = f.read().strip()

            client = Groq(api_key=api_key)
            messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self._history

            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=messages,
                max_tokens=300,
                temperature=0.8,
            )
            self.result_ready.emit(response.choices[0].message.content.strip())
        except Exception as e:
            self.error_occurred.emit(f"⚠️ Error: {e}")


# ── Message bubble widget ───────────────────────────────────────────────────

class _Bubble(QFrame):
    """A single chat message bubble."""

    def __init__(self, text: str, is_user: bool, parent=None):
        super().__init__(parent)

        if is_user:
            bg   = "#00E676"
            fg   = "#003300"
            align = Qt.AlignRight
        else:
            bg   = "#1A2F25"
            fg   = "#E0E0E0"
            align = Qt.AlignLeft

        label = QLabel(text)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        label.setStyleSheet(f"""
            QLabel {{
                background-color: {bg};
                color: {fg};
                border-radius: 12px;
                padding: 10px 14px;
                font-size: 13px;
                line-height: 1.5;
            }}
        """)
        label.setMaximumWidth(520)
        label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)

        row = QHBoxLayout()
        row.setContentsMargins(8, 3, 8, 3)
        if is_user:
            row.addStretch()
            row.addWidget(label)
        else:
            row.addWidget(label)
            row.addStretch()

        self.setLayout(row)


# ── Input box that sends on Enter ──────────────────────────────────────────

class _ChatInput(QLineEdit):
    send_requested = Signal()

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.send_requested.emit()
        else:
            super().keyPressEvent(event)


# ── Main chatbot tab ────────────────────────────────────────────────────────

class ChatbotTab(QWidget):
    """Full conversational AI chat tab."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._history   = []   # OpenAI-style message dicts
        self._worker    = None
        self._typing_timer = QTimer(self)
        self._typing_timer.setSingleShot(True)

        # ── Layout ──────────────────────────────────────────────────────
        root = QVBoxLayout()
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        header = QLabel("🤖  AI Focus Coach")
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet(
            "font-size: 18px; font-weight: bold; color: #00E676;"
            "padding: 14px; background-color: #0d1611;"
        )

        # Scroll area for bubbles
        self._bubbles_widget = QWidget()
        self._bubbles_layout = QVBoxLayout(self._bubbles_widget)
        self._bubbles_layout.setAlignment(Qt.AlignTop)
        self._bubbles_layout.setSpacing(4)
        self._bubbles_layout.setContentsMargins(4, 8, 4, 8)

        self._scroll = QScrollArea()
        self._scroll.setWidget(self._bubbles_widget)
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet(
            "QScrollArea { border: none; background-color: #0d1611; }"
        )

        # Typing indicator (shown while Groq is thinking)
        self._typing_label = QLabel("🤔  Thinking…")
        self._typing_label.setAlignment(Qt.AlignLeft)
        self._typing_label.setStyleSheet(
            "color: #555; font-size: 12px; padding: 4px 16px;"
        )
        self._typing_label.hide()

        # Input row
        self._input = _ChatInput()
        self._input.setPlaceholderText("Type a message… (Enter to send)")
        self._input.setStyleSheet("""
            QLineEdit {
                background-color: #1A2F25;
                color: #E0E0E0;
                border: 1px solid #2E5A3E;
                border-radius: 20px;
                padding: 10px 16px;
                font-size: 13px;
            }
        """)
        self._input.send_requested.connect(self._send)

        self._send_btn = QPushButton("Send ➤")
        self._send_btn.setFixedWidth(90)
        self._send_btn.setStyleSheet("""
            QPushButton {
                background-color: #00E676;
                color: #003300;
                border-radius: 20px;
                padding: 10px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover { background-color: #33FF99; }
            QPushButton:disabled { background-color: #2E3E34; color: #555; }
        """)
        self._send_btn.clicked.connect(self._send)

        input_row = QHBoxLayout()
        input_row.setContentsMargins(12, 8, 12, 12)
        input_row.setSpacing(8)
        input_row.addWidget(self._input)
        input_row.addWidget(self._send_btn)

        # Assemble
        root.addWidget(header)
        root.addWidget(self._scroll, stretch=1)
        root.addWidget(self._typing_label)
        root.addLayout(input_row)
        self.setLayout(root)

        # Opening greeting (no API call yet — just local)
        self._add_bubble(
            "Hey! 👋  I'm your AI focus coach. You can chat with me whenever you need help, "
            "feel stuck, or just want a break suggestion. What's on your mind?",
            is_user=False
        )

    # ── Public API ───────────────────────────────────────────────────────────

    def trigger_stuck(self):
        """Called by the Focus tab's 'I'm stuck' button."""
        self._submit_user_message("I'm stuck and feeling overwhelmed. What should I do?")

    # ── Private helpers ──────────────────────────────────────────────────────

    def _send(self):
        text = self._input.text().strip()
        if not text:
            return
        self._input.clear()
        self._submit_user_message(text)

    def _submit_user_message(self, text: str):
        if self._worker and self._worker.isRunning():
            return  # ignore while AI is typing

        self._add_bubble(text, is_user=True)
        self._history.append({"role": "user", "content": text})

        self._set_loading(True)

        self._worker = _GroqWorker(list(self._history))
        self._worker.result_ready.connect(self._on_result)
        self._worker.error_occurred.connect(self._on_error)
        self._worker.start()

    def _add_bubble(self, text: str, is_user: bool):
        bubble = _Bubble(text, is_user)
        self._bubbles_layout.addWidget(bubble)
        # Scroll to bottom after layout updates
        QTimer.singleShot(50, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        sb = self._scroll.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _set_loading(self, loading: bool):
        self._typing_label.setVisible(loading)
        self._send_btn.setEnabled(not loading)
        self._input.setEnabled(not loading)

    def _on_result(self, text: str):
        self._history.append({"role": "assistant", "content": text})
        self._add_bubble(text, is_user=False)
        self._set_loading(False)
        self._input.setFocus()

    def _on_error(self, msg: str):
        self._add_bubble(msg, is_user=False)
        self._set_loading(False)
        self._input.setFocus()
