from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QDialog, QTableWidget, QTableWidgetItem, QHeaderView
)
from PySide6.QtCore import QTimer, QTime, Qt, QSettings
from Services.focus_service import (
    start_session, end_session, 
    get_today_total_seconds, get_history_stats,
    get_current_max_index, get_detailed_history, reset_history
)
from datetime import datetime


class StatisticsDialog(QDialog):
    """Prikazuje dnevno statistiko in cilje."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Statistika")
        self.resize(500, 400)
        self.setStyleSheet("background-color: #1A2F25; color: white;")
        
        layout = QVBoxLayout()
        
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Datum", "Skupaj Čas", "Uspeh / Manjkajoče"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("""
            QTableWidget { border: none; gridline-color: #2E5A3E; }
            QHeaderView::section { background-color: #2E5A3E; padding: 4px; border: none; }
        """)
        
        layout.addWidget(QLabel("Dnevna Statistika (Pretekli dnevi):"))
        layout.addWidget(self.table)
        self.setLayout(layout)
        
        self.load_data()
        
    def load_data(self):
        stats = get_history_stats()
        
        # Filter out today (User request: "dont display anything untill the full day has been completed")
        today_str = QTime.currentTime().toString() # fail
        from datetime import datetime
        today_str = datetime.now().strftime("%Y-%m-%d")
        
        past_stats = [s for s in stats if s["date"] != today_str]
        
        self.table.setRowCount(len(past_stats))
        
        for i, entry in enumerate(past_stats):
            seconds = entry["total_seconds"]
            hours = seconds // 3600
            mins = (seconds % 3600) // 60
            time_str = f"{hours}h {mins}m"
            
            goal_seconds = 3 * 3600
            if seconds >= goal_seconds:
                goal_text = "✅ Cilj dosežen"
            else:
                missing = goal_seconds - seconds
                m_h = missing // 3600
                m_m = (missing % 3600) // 60
                goal_text = f"❌ Manjka: {m_h}h {m_m}m"
            
            self.table.setItem(i, 0, QTableWidgetItem(entry["date"]))
            self.table.setItem(i, 1, QTableWidgetItem(time_str))
            
            item_goal = QTableWidgetItem(goal_text)
            item_goal.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 2, item_goal)


class HistoryDialog(QDialog):
    """Prikazuje podrobno zgodovino po sejah."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Zgodovina Sej")
        self.resize(500, 400)
        self.setStyleSheet("background-color: #1A2F25; color: white;")
        
        layout = QVBoxLayout()
        
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Datum", "Seja", "Trajanje"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("""
            QTableWidget { border: none; gridline-color: #2E5A3E; }
            QHeaderView::section { background-color: #2E5A3E; padding: 4px; border: none; }
        """)
        
        layout.addWidget(QLabel("Zgodovina po sejah (Aggregated):"))
        layout.addWidget(self.table)
        self.setLayout(layout)
        
        self.load_data()
        
    def load_data(self):
        # Dobimo podatke, grupirane po sejah
        detailed_history = get_detailed_history() 
        self.table.setRowCount(len(detailed_history))
        
        for i, entry in enumerate(detailed_history):
            date_str = entry["date"]
            session_idx = entry.get("session_index", "?")
            total_sec = entry["total_seconds"]
            
            # Format duration
            mins = total_sec // 60
            secs = total_sec % 60
            dur_str = f"{mins}m {secs}s"
            
            if total_sec >= 60:
                dur_str = f"{mins}m" # Show simpler format if longer
            
            self.table.setItem(i, 0, QTableWidgetItem(date_str))
            self.table.setItem(i, 1, QTableWidgetItem(f"Session {session_idx}"))
            self.table.setItem(i, 2, QTableWidgetItem(dur_str))


class FocusTab(QWidget):
    """Pomodoro style focus tab v 'Dark Mode' stilu."""
    
    DAILY_GOAL_SECONDS = 3 * 3600 # 3 ure
    SESSION_DURATION = 45 * 60   # 45 minut

    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.session_id = None
        self.is_running = False
        self.timer_seconds = self.SESSION_DURATION
        
        # Session state
        # 0 = Before start (Show "Start Session X")
        # 1 = Running/Paused (Show Timer)
        # 2 = Finished (Show "Next Session")
        self.state = 0 
        
        # Calculate current session index based on DB
        self.current_session_index = get_current_max_index() + 1
        
        # Timer za odštevanje
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        
        # --- UI SETUP ---
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.setSpacing(30)
        
        # 1. Header / Daily Status
        self.daily_label = QLabel("Daily Goal Left: 3h 0m")
        self.daily_label.setStyleSheet("color: #888; font-size: 14px; font-weight: bold;")
        self.daily_label.setAlignment(Qt.AlignCenter)
        
        # 2. Main Content Area (Stack or Swap)
        # --> START BTN
        self.start_session_btn = QPushButton(f"Start Session {self.current_session_index}")
        self.start_session_btn.setFixedSize(200, 60)
        self.start_session_btn.setStyleSheet("""
            QPushButton { background-color: #00E676; color: #0b1410; border-radius: 30px; font-size: 18px; font-weight: bold; }
            QPushButton:hover { background-color: #33FF99; }
        """)
        self.start_session_btn.clicked.connect(self.user_start_session)
        
        # --> TIMER LABEL
        self.time_label = QLabel("45:00")
        self.time_label.setStyleSheet("font-size: 100px; font-weight: bold; color: white;")
        self.time_label.setAlignment(Qt.AlignCenter)
        self.time_label.hide()
        
        # --> CONTROLS
        self.controls_widget = QWidget()
        controls_layout = QHBoxLayout(self.controls_widget)
        controls_layout.setAlignment(Qt.AlignCenter)
        controls_layout.setSpacing(40)
        
        # History Button
        self.history_btn = QPushButton("📜") 
        self.history_btn.setFixedSize(50, 50)
        self.history_btn.setStyleSheet("QPushButton { background-color: #2E3E34; border-radius: 25px; font-size: 20px; }")
        self.history_btn.clicked.connect(self.open_history)
        
        # Play/Pause Button
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(90, 90)
        self.play_btn.setStyleSheet("""
            QPushButton { 
                background-color: #00E676; 
                color: #0b1410; 
                border-radius: 45px; 
                font-size: 40px; 
                padding-left: 5px; /* Visual fix for triangle center */
            }
            QPushButton:hover { background-color: #33FF99; }
        """)
        self.play_btn.clicked.connect(self.toggle_timer)
        
        # Statistics Button
        self.stats_btn = QPushButton("📊")
        self.stats_btn.setFixedSize(50, 50)
        self.stats_btn.setStyleSheet("QPushButton { background-color: #2E3E34; border-radius: 25px; font-size: 20px; }")
        self.stats_btn.clicked.connect(self.open_stats)
        
        controls_layout.addWidget(self.history_btn)
        controls_layout.addWidget(self.play_btn)
        controls_layout.addWidget(self.stats_btn) 
        
        self.controls_widget.hide()
        
        # 4. "I'm Stuck" Button
        self.stuck_btn = QPushButton("⚡ I'm stuck")
        self.stuck_btn.setFixedWidth(200)
        self.stuck_btn.setStyleSheet("""
            QPushButton { background-color: #2E3E34; color: #EEE; border-radius: 20px; padding: 10px; font-weight: bold; }
            QPushButton:hover { background-color: #3E4E45; }
        """)
        self.stuck_btn.clicked.connect(self._on_stuck)
        
        main_layout.addWidget(self.daily_label)
        main_layout.addSpacing(40)
        main_layout.addWidget(self.start_session_btn, 0, Qt.AlignCenter)
        main_layout.addWidget(self.time_label)
        main_layout.addSpacing(10)
        main_layout.addWidget(self.controls_widget)
        main_layout.addSpacing(40)
        main_layout.addWidget(self.stuck_btn, 0, Qt.AlignCenter)
        
        self.setLayout(main_layout)
        
        self.update_daily_display()
        
        # Load persisted state
        self.load_state()
        
    def _on_stuck(self):
        """
        [AI DODATEK]: Preklopi na AI tab ko je uporabnik stuck.
        Ta funkcija poišče glavno okno aplikacije in pokliče njegovo funkcijo 
        switch_to_chatbot(), ki odpre AI zavihek in avtomatsko pošlje sporočilo.
        """
        main_win = self.window()
        if hasattr(main_win, "switch_to_chatbot"):
            main_win.switch_to_chatbot()

    def user_start_session(self):
        """Uporabnik klikne 'Start Session X'."""
        self.state = 1 # Running mode
        self.start_session_btn.hide()
        self.time_label.show()
        self.controls_widget.show()
        
        self.timer_seconds = self.SESSION_DURATION
        self.update_display()
        
        # Avtomatsko startaj
        self.start_timer()
        
    def reset_ui_state(self):
        """Resetira UI na zacetno stanje (klicano iz SettingsTab)."""
        self.stop_timer()
        self.current_session_index = 1
        self.timer_seconds = self.SESSION_DURATION
        self.state = 0
        
        # Refresh Display
        self.update_display()
        self.update_daily_display()
        
        # Reset UI controls
        self.time_label.hide()
        self.controls_widget.hide()
        self.start_session_btn.setText(f"Start Session {self.current_session_index}")
        self.start_session_btn.show()
        
    def tick(self):
        if self.timer_seconds > 0:
            self.timer_seconds -= 1
            self.update_display()
        else:
            # Timer finished naturally -> Session Complete
            self.session_finished()
            
    def session_finished(self):
        self.stop_timer()
        self.timer_seconds = self.SESSION_DURATION
        self.update_display()
        
        # Povecaj session index
        self.current_session_index += 1
        self.state = 0
        
        # Update UI back to 'Start' state
        self.time_label.hide()
        self.controls_widget.hide()
        
        self.start_session_btn.setText(f"Start Session {self.current_session_index}")
        self.start_session_btn.show()
        
    def update_display(self):
        mins = self.timer_seconds // 60
        secs = self.timer_seconds % 60
        self.time_label.setText(f"{mins:02d}:{secs:02d}")
        
    def update_daily_display(self):
        """Preveri koliko casa je se do cilja."""
        done_today = get_today_total_seconds()
        remaining = max(0, self.DAILY_GOAL_SECONDS - done_today)
        
        h = remaining // 3600
        m = (remaining % 3600) // 60
        
        if remaining == 0:
            self.daily_label.setText("🎉 Daily Goal Achieved! 🎉")
            self.daily_label.setStyleSheet("color: #00E676; font-size: 14px; font-weight: bold;")
        else:
            self.daily_label.setText(f"Daily Goal Remaining: {h}h {m}m")
            self.daily_label.setStyleSheet("color: #888; font-size: 14px; font-weight: bold;")

    def toggle_timer(self):
        if self.is_running:
            self.stop_timer()
        else:
            self.start_timer()
            
    def start_timer(self):
        if self.session_id is None:
             self.session_id, _ = start_session(self.current_session_index)
        
        self.is_running = True
        self.play_btn.setText("⏸") 
        self.timer.start(1000)
        
    def stop_timer(self):
        self.is_running = False
        self.play_btn.setText("▶") 
        self.timer.stop()
        
        if self.session_id:
            end_session(self.session_id)
            self.session_id = None
            self.update_daily_display()

    def reset_timer(self):
        # Reset Logic is technically mostly redundant now without the button, 
        # but kept if we need internal reset.
        self.stop_timer()
        self.timer_seconds = self.SESSION_DURATION
        self.update_display()
        
    def open_history(self):
        dlg = HistoryDialog(self)
        dlg.exec()
        
    def open_stats(self):
        dlg = StatisticsDialog(self)
        dlg.exec()

    def save_state(self):
        """Shrani stanje timera ob zaprtju aplikacije."""
        settings = QSettings("FocusMate", "TimerState")
        settings.setValue("timer_seconds", self.timer_seconds)
        settings.setValue("current_session_index", self.current_session_index)
        settings.setValue("state", self.state)
        # Save current date to invalidate settings on new day
        settings.setValue("save_date", datetime.now().strftime("%Y-%m-%d"))
        
        # Clean up database session if running
        if self.is_running and self.session_id:
            end_session(self.session_id)
            
    def load_state(self):
        """Nalozi stanje timera ob zagonu."""
        settings = QSettings("FocusMate", "TimerState")
        
        saved_date = settings.value("save_date", "")
        today_str = datetime.now().strftime("%Y-%m-%d")
        
        # Ce datum shranjevanja NI danes, ignoriraj stare nastavitve (Daily Reset)
        if saved_date != today_str:
            return 

        try:
            saved_seconds = int(settings.value("timer_seconds", self.SESSION_DURATION))
            saved_index = int(settings.value("current_session_index", self.current_session_index))
            saved_state = int(settings.value("state", 0))
            
            # Update values
            self.timer_seconds = saved_seconds

            # When restoring an in-progress session (state 1) we must use
            # the exact saved index.  Using max() would over-count because
            # save_state() calls end_session() which already wrote that
            # session to the DB, making get_current_max_index()+1 one too high.
            if saved_state == 1:
                self.current_session_index = saved_index
            else:
                self.current_session_index = max(self.current_session_index, saved_index)
            self.state = saved_state
            
            self.update_display()
            
            # Restore UI State
            if self.state == 1: # Was Running/Paused
                self.start_session_btn.hide()
                self.time_label.show()
                self.controls_widget.show()
                # Always start paused
                self.play_btn.setText("▶")
                self.is_running = False
                
            elif self.state == 0: # Idle
                self.start_session_btn.setText(f"Start Session {self.current_session_index}")
                self.start_session_btn.show()
                self.time_label.hide()
                self.controls_widget.hide()
                
        except Exception as e:
            print(f"Error loading settings: {e}")
