from PySide6.QtWidgets import QMainWindow, QTabWidget, QWidget
from UI.notes_tab import NotesTab  

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Student Productivity Dashboard")
        self.resize(900, 600)

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Ustvarimo notes tab
        self.notes_tab = NotesTab()
        self.tabs.addTab(self.notes_tab, "Opombe")

        # Zaenkrat dodaj placeholder za druge zavihke
        self.tabs.addTab(QWidget(), "Naloge")
        self.tabs.addTab(QWidget(), "Fokus")
