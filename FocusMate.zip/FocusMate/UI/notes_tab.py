from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout,
    QListWidget, QListWidgetItem,
    QLineEdit, QTextEdit, QPushButton, QMessageBox
)
from PySide6.QtCore import Qt, QObject, QEvent
from Services.notes_service import load_notes, save_notes


class NotesTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.notes = load_notes()
        self.current_index = None  # None = ustvarjamo novo opombo

        # Levi del – seznam opomb
        self.list_widget = QListWidget()
        self.list_widget.currentRowChanged.connect(self.on_note_selected)
        # poslušamo klike na prazen prostor
        self.list_widget.viewport().installEventFilter(self)

        # Desni del – naslov + vsebina
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Naslov opombe")

        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("Vsebina opombe")

        self.btn_save = QPushButton("Shrani")
        self.btn_delete = QPushButton("Izbriši")

        self.btn_save.clicked.connect(self.save_note)
        self.btn_delete.clicked.connect(self.delete_current_note)

        # Layouti
        left_layout = QVBoxLayout()
        left_layout.addWidget(self.list_widget)

        right_layout = QVBoxLayout()
        right_layout.addWidget(self.title_edit)
        right_layout.addWidget(self.content_edit)
        right_layout.addWidget(self.btn_save)
        right_layout.addWidget(self.btn_delete)

        main_layout = QHBoxLayout()
        main_layout.addLayout(left_layout, 2)
        main_layout.addLayout(right_layout, 3)
        self.setLayout(main_layout)

        self.load_list()

    # ---------- helperji ----------

    def load_list(self):
        """Napolni levi seznam iz self.notes."""
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        for note in self.notes:
            item = QListWidgetItem(note.get("title", "Neimenovana"))
            self.list_widget.addItem(item)
        self.list_widget.blockSignals(False)

    def clear_editor(self):
        """Pobriše polja in preklopi v 'nova opomba' modo."""
        self.title_edit.clear()
        self.content_edit.clear()
        self.current_index = None
        self.list_widget.clearSelection()

    # ---------- signali ----------

    def on_note_selected(self, index: int):
        """Ko uporabnik izbere opombo v seznamu."""
        if index < 0 or index >= len(self.notes):
            # nič izbrano -> pripravi za novo opombo
            self.clear_editor()
            return

        self.current_index = index
        note = self.notes[index]
        self.title_edit.setText(note.get("title", ""))
        self.content_edit.setText(note.get("content", ""))

    # ---------- logika ----------

    def save_note(self):
        """Shrani novo ali posodobi obstoječo opombo."""
        title = self.title_edit.text().strip()
        content = self.content_edit.toPlainText().strip()

        if not title and not content:
            QMessageBox.warning(self, "Napaka", "Opomba je prazna.")
            return

        if self.current_index is None:
            # NOVA opomba
            self.notes.append({
                "id": len(self.notes) + 1,
                "title": title or "Neimenovana",
                "content": content,
            })
            save_notes(self.notes)
            self.load_list()
            # po shranjevanju nove opombe pripravi na naslednjo
            self.clear_editor()
        else:
            # UREJANJE obstoječe
            self.notes[self.current_index]["title"] = title or "Neimenovana"
            self.notes[self.current_index]["content"] = content
            save_notes(self.notes)
            self.load_list()
            self.list_widget.setCurrentRow(self.current_index)

    def delete_current_note(self):
        """Izbriše trenutno izbrano opombo."""
        if self.current_index is None:
            return

        reply = QMessageBox.question(
            self, "Potrditev", "Res želiš izbrisati opombo?"
        )
        if reply != QMessageBox.Yes:
            return

        self.notes.pop(self.current_index)
        save_notes(self.notes)
        self.load_list()
        self.clear_editor()

    # ---------- event filter & tipke ----------

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        # klik na prazen prostor v seznamu -> nova opomba
        if obj is self.list_widget.viewport() and event.type() == QEvent.MouseButtonPress:
            if self.list_widget.itemAt(event.pos()) is None:
                # prisilno resetiraj selection, da Qt zazna naslednjo spremembo
                self.list_widget.setCurrentRow(-1)
                self.clear_editor()
        return super().eventFilter(obj, event)

    def keyPressEvent(self, event):
        # ESC -> nova opomba (reset polj)
        if event.key() == Qt.Key_Escape:
            self.clear_editor()
        else:
            super().keyPressEvent(event)
