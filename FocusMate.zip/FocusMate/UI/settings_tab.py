from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QLabel, QMessageBox, QFrame
)
from PySide6.QtCore import Qt, Signal, QSettings
from Services.focus_service import reset_history

class SettingsTab(QWidget):
    """Zavihek z nastavitvami aplikacije."""
    
    # Signal, ki sporoci, da je bil izveden hard reset
    data_reset = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)
        layout.setSpacing(20)
        
        # Header
        header = QLabel("Nastavitve")
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #00E676;")
        layout.addWidget(header)
        
        # Space
        layout.addSpacing(20)
        
        # Danger Zone Frame
        danger_frame = QFrame()
        danger_frame.setStyleSheet("""
            QFrame {
                background-color: #2E1A1A; 
                border: 1px solid #FF5252; 
                border-radius: 10px;
            }
        """)
        danger_layout = QVBoxLayout(danger_frame)
        
        danger_label = QLabel("Nevarno Območje")
        danger_label.setStyleSheet("color: #FF5252; font-weight: bold; font-size: 16px; border: none;")
        
        self.hard_reset_btn = QPushButton("🗑️ Hard Reset App")
        self.hard_reset_btn.setToolTip("Izbrise vse podatke in nastavitve")
        self.hard_reset_btn.setStyleSheet("""
            QPushButton { 
                background-color: #3E2E2E; 
                color: #FF5252;
                border: 1px solid #FF5252;
                border-radius: 8px; 
                font-size: 16px; 
                padding: 10px;
            }
            QPushButton:hover { background-color: #FF5252; color: white; }
        """)
        self.hard_reset_btn.clicked.connect(self.perform_hard_reset)
        
        danger_layout.addWidget(danger_label)
        danger_layout.addWidget(self.hard_reset_btn)
        
        layout.addWidget(danger_frame)
        # Colors Section
        colors_label = QLabel("Barve (Teme)")
        colors_label.setStyleSheet("color: #00E676; font-weight: bold; font-size: 16px;")
        layout.addWidget(colors_label)

        self.btn_bg_color = QPushButton("Set Background Color")
        self.btn_btn_color = QPushButton("Set Button Color")
        self.btn_reset_colors = QPushButton("Ponastavi barve na privzeto")
        
        self.btn_bg_color.setStyleSheet("background-color: #3E2E2E; color: white;")
        self.btn_btn_color.setStyleSheet("background-color: #3E2E2E; color: white;")
        self.btn_reset_colors.setStyleSheet("background-color: #3E2E2E; color: lightgray;")
        
        self.btn_bg_color.clicked.connect(self.choose_bg_color)
        self.btn_btn_color.clicked.connect(self.choose_btn_color)
        self.btn_reset_colors.clicked.connect(self.reset_colors)
        
        layout.addWidget(self.btn_bg_color)
        layout.addWidget(self.btn_btn_color)
        layout.addWidget(self.btn_reset_colors)

        layout.addStretch()
        
        self.setLayout(layout)

    def choose_bg_color(self):
        from PySide6.QtWidgets import QColorDialog
        from PySide6.QtGui import QColor
        settings = QSettings("FocusMate", "Settings")
        current_color = settings.value("bg_color", "#0d1611")
        color = QColorDialog.getColor(QColor(current_color), self, "Izberi barvo ozadja")
        if color.isValid():
            settings.setValue("bg_color", color.name())
            self.data_reset.emit()  # Lahko uporabimo obstoječ signal ali ustvarimo novega za okno

    def choose_btn_color(self):
        from PySide6.QtWidgets import QColorDialog
        from PySide6.QtGui import QColor
        settings = QSettings("FocusMate", "Settings")
        current_color = settings.value("Theme", "#00E676") # Wait, should use btn_color
        current_color = settings.value("btn_color", "#00E676")
        color = QColorDialog.getColor(QColor(current_color), self, "Izberi barvo gumbov")
        if color.isValid():
            settings.setValue("btn_color", color.name())
            self.data_reset.emit()

    def reset_colors(self):
        settings = QSettings("FocusMate", "Settings")
        settings.setValue("bg_color", "#0d1611")
        settings.setValue("btn_color", "#00E676")
        self.data_reset.emit()

    def perform_hard_reset(self):
        """Popoln reset aplikacije (Data + Settings)."""
        confirm = QMessageBox.question(
            self, "Hard Reset", 
            "Ali ste prepričani? To bo izbrisalo VSO zgodovino in nastavitve.\nAplikacija bo ponastavljena.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if confirm == QMessageBox.Yes:
            # 1. Clear Settings
            settings = QSettings("FocusMate", "TimerState")
            settings.clear()
            
            # 2. Clear Database
            reset_history()
            
            # 3. Emit signal to notify other tabs (Main window handles this)
            self.data_reset.emit()
            
            QMessageBox.information(
                self, "Reset Complete", 
                "Aplikacija je bila uspešno ponastavljena!"
            )
