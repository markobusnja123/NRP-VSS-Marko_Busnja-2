from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QComboBox, QDateEdit,
    QPushButton, QListWidget, QListWidgetItem, QLabel, QDialog, QDialogButtonBox,
    QMessageBox
)
from PySide6.QtCore import QDate, Qt, Signal
from Services.tasks_service import load_tasks, add_task, update_task, delete_task


class TaskEditDialog(QDialog):
    """Majhen dialog za urejanje ene naloge."""

    def __init__(self, task, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Uredi nalogo")
        self.task = task  # dict z id, title, priority, due ...

        # inputi
        self.title_edit = QLineEdit(task["title"])

        self.priority_combo = QComboBox()
        self.priority_combo.addItems(["Nujno", "Srednje", "Nizko"])
        index = self.priority_combo.findText(task["priority"])
        if index >= 0:
            self.priority_combo.setCurrentIndex(index)

        self.due_date_edit = QDateEdit()
        self.due_date_edit.setCalendarPopup(True)
        year, month, day = map(int, task["due"].split("-"))
        self.due_date_edit.setDate(QDate(year, month, day))

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        form_layout = QVBoxLayout()

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Naloga:"))
        row1.addWidget(self.title_edit)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Nujnost:"))
        row2.addWidget(self.priority_combo)
        row2.addWidget(QLabel("Rok:"))
        row2.addWidget(self.due_date_edit)

        form_layout.addLayout(row1)
        form_layout.addLayout(row2)
        form_layout.addWidget(button_box)

        self.setLayout(form_layout)

    def get_updated_task(self):
        """Vrne (title, priority, due_str) iz dialoga."""
        title = self.title_edit.text().strip()
        priority = self.priority_combo.currentText()
        due_qdate = self.due_date_edit.date()
        due_str = due_qdate.toString("yyyy-MM-dd")
        return title, priority, due_str


class TaskItemWidget(QWidget):
    """Custom widget za prikaz naloge v seznamu."""
    
    deleteClicked = Signal()  # Signal, ki ga oddamo, ko uporabnik klikne delete

    def __init__(self, task, parent=None):
        super().__init__(parent)
        
        self.task = task
        layout = QHBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Leva stran: Naslov in Priority
        left_layout = QVBoxLayout()
        self.title_label = QLabel(task['title'])
        self.title_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        
        self.priority_label = QLabel(f"Priority: {task['priority']}")
        self.priority_label.setStyleSheet("color: gray; font-size: 12px;")
        
        left_layout.addWidget(self.title_label)
        left_layout.addWidget(self.priority_label)
        
        # Desna stran: Status in Datum
        right_layout = QVBoxLayout()
        right_layout.setAlignment(Qt.AlignRight)
        
        # Izracun statusa
        today = QDate.currentDate()
        due_date = QDate.fromString(task['due'], "yyyy-MM-dd")
        days_diff = today.daysTo(due_date)
        
        status_text = ""
        status_style = ""
        
        if days_diff < 0:
            status_text = "EXPIRED"
            status_style = "color: white; background-color: #ff4d4d; border-radius: 4px; padding: 2px 6px; font-weight: bold;"
        elif days_diff == 0:
            status_text = "TODAY"
            status_style = "color: black; background-color: #ffcc00; border-radius: 4px; padding: 2px 6px; font-weight: bold;"
        else:
            status_text = f"{days_diff} DAYS LEFT"
            status_style = "color: white; background-color: #4CAF50; border-radius: 4px; padding: 2px 6px; font-weight: bold;"
            
        self.status_label = QLabel(status_text)
        self.status_label.setStyleSheet(status_style)
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setFixedWidth(100) # Fixed width for alignment

        self.date_label = QLabel(f"Due: {task['due']}")
        self.date_label.setStyleSheet("color: gray; font-size: 11px;")
        self.date_label.setAlignment(Qt.AlignRight)
        
        right_layout.addWidget(self.status_label)
        right_layout.addWidget(self.date_label)
        
        # Gumb za brisanje
        self.delete_btn = QPushButton("✕") 
        self.delete_btn.setFixedSize(32, 32)
        # Red styling specific for delete button (overrides global button style)
        self.delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF5252; 
                color: white; 
                border-radius: 16px;
                font-weight: bold;
                font-size: 16px;
                padding: 0;
            }
            QPushButton:hover {
                background-color: #FF1744;
            }
        """)
        self.delete_btn.clicked.connect(self.deleteClicked.emit)
        
        layout.addLayout(left_layout, stretch=1)
        layout.addLayout(right_layout)
        layout.addSpacing(10)
        layout.addWidget(self.delete_btn)
        
        # Container style for the whole item
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet("""
            TaskItemWidget {
                background-color: #1A2F25;
                border-radius: 10px;
                border: 1px solid #2E5A3E;
            }
        """)
        
        self.setLayout(layout)


class TasksTab(QWidget):
    """Zavihek Naloge – seznam z nujnostjo in rokom, shranjen v SQLite."""

    PRIORITY_ORDER = {
        "Nujno": 0,
        "Srednje": 1,
        "Nizko": 2,
    }

    def __init__(self, parent=None):
        super().__init__(parent)

        # 1) preberi naloge iz baze
        self.tasks = load_tasks()  # list dictov, vsak ima 'id', 'title', ...

        # --- zgornji input del ---

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Opis naloge (npr. 'Ponovi matematiko')")

        self.priority_combo = QComboBox()
        self.priority_combo.addItems(["Nujno", "Srednje", "Nizko"])

        self.due_date_edit = QDateEdit()
        self.due_date_edit.setCalendarPopup(True)
        self.due_date_edit.setDate(QDate.currentDate())

        self.add_button = QPushButton("Dodaj nalogo")
        self.add_button.clicked.connect(self.add_task)

        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("Naloga:"))
        input_layout.addWidget(self.title_edit, 3)
        input_layout.addWidget(QLabel("Nujnost:"))
        input_layout.addWidget(self.priority_combo)
        input_layout.addWidget(QLabel("Rok:"))
        input_layout.addWidget(self.due_date_edit)
        input_layout.addWidget(self.add_button)

        # --- spodnji del – seznam nalog ---

        self.tasks_list = QListWidget()
        # Enable styling for the list widget item containers if needed, 
        # but mostly we style the widget inside.
        
        self.tasks_list.itemDoubleClicked.connect(self.edit_task_dialog)

        main_layout = QVBoxLayout()
        main_layout.addLayout(input_layout)
        main_layout.addWidget(self.tasks_list)
        self.setLayout(main_layout)

        # 2) napolni seznam iz self.tasks
        self.refresh_list()

    # --------- helperji ----------

    def sort_tasks(self):
        """Sortira tasks v spominu po nujnosti in datumu."""
        self.tasks.sort(key=lambda t: (t["priority_rank"], t["due"]))

    def refresh_list(self):
        """Osveži QListWidget iz self.tasks."""
        self.tasks_list.clear()
        
        for task in self.tasks:
            item = QListWidgetItem()
            widget = TaskItemWidget(task)
            
            # Povezava za brisanje
            # Uporabimo lambda z default argumentom, da ujamemo pravi task ID
            widget.deleteClicked.connect(lambda t_id=task["id"]: self.delete_task_action(t_id))
            
            # Set size hint so the item has correct height
            item.setSizeHint(widget.sizeHint())
            
            self.tasks_list.addItem(item)
            self.tasks_list.setItemWidget(item, widget)

    def delete_task_action(self, task_id):
        """Izbrise nalogo iz baze in osvezi seznam."""
        reply = QMessageBox.question(
            self, 
            "Potrdi brisanje", 
            "Ali res želiš izbrisati to nalogo?",
            QMessageBox.Yes | QMessageBox.No, 
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            delete_task(task_id)
            
            # Remove from local list
            self.tasks = [t for t in self.tasks if t["id"] != task_id]
            
            self.refresh_list()

    # --------- dodajanje ----------

    def add_task(self):
        """Doda novo nalogo (v spomin in SQLite)."""
        title = self.title_edit.text().strip()
        if not title:
            return

        priority = self.priority_combo.currentText()
        due_qdate = self.due_date_edit.date()
        due_str = due_qdate.toString("yyyy-MM-dd")

        priority_rank = self.PRIORITY_ORDER[priority]

        task_id = add_task(title, priority, priority_rank, due_str)

        task = {
            "id": task_id,
            "title": title,
            "priority": priority,
            "priority_rank": priority_rank,
            "due": due_str,
        }
        self.tasks.append(task)

        self.sort_tasks()
        self.refresh_list()

        self.title_edit.clear()

    # --------- urejanje ----------

    def edit_task_dialog(self, item: QListWidgetItem):
        """Odpre dialog za urejanje izbrane naloge."""
        row = self.tasks_list.row(item)
        task = self.tasks[row]

        dlg = TaskEditDialog(task, self)
        if dlg.exec():
            title, priority, due_str = dlg.get_updated_task()
            if title:
                task["title"] = title
            task["priority"] = priority
            task["due"] = due_str
            task["priority_rank"] = self.PRIORITY_ORDER[priority]

            update_task(task)

            self.sort_tasks()
            self.refresh_list()
