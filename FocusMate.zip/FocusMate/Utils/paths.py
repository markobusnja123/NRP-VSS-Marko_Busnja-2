from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "Data"

NOTES_FILE = DATA_DIR / "notes.json"
APP_SETTINGS_FILE = DATA_DIR / "app_settings.json"

def ensure_data_files():
    DATA_DIR.mkdir(exist_ok=True)
    if not NOTES_FILE.exists():
        NOTES_FILE.write_text("[]", encoding="utf-8")
    if not APP_SETTINGS_FILE.exists():
        APP_SETTINGS_FILE.write_text("{}", encoding="utf-8")
