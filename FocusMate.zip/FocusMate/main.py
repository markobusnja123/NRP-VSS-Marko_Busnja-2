import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget
from UI.notes_tab import NotesTab
from UI.tasks_tab import TasksTab
from UI.focus_tab import FocusTab
from UI.settings_tab import SettingsTab
from UI.chatbot_tab import ChatbotTab
from Utils.paths import ensure_data_files
from Services.db_service import init_db


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Student Productivity Dashboard")
        self.resize(1000, 700)

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # 1. zavihek – Opombe
        self.notes_tab = NotesTab(self)
        self.tabs.addTab(self.notes_tab, "Opombe")

        # 2. zavihek – Naloge
        self.tasks_tab = TasksTab(self)
        self.tabs.addTab(self.tasks_tab, "Naloge")

        # 3. zavihek – Fokus
        self.focus_tab = FocusTab(self)
        self.tabs.addTab(self.focus_tab, "Fokus")

        # 4. zavihek – Nastavitve
        self.settings_tab = SettingsTab(self)
        self.tabs.addTab(self.settings_tab, "Nastavitve")

        # 5. zavihek – AI Pomočnik
        # [AI DODATEK]: Tukaj inicializiramo naš nov AI Chatbot zavihek, 
        # ki uporablja Groq API, ter ga dodamo v seznam vseh zavihkov.
        self.chatbot_tab = ChatbotTab(self)
        self.tabs.addTab(self.chatbot_tab, "🤖 AI")

        # Signals
        self.settings_tab.data_reset.connect(self.focus_tab.reset_ui_state)
        self.settings_tab.data_reset.connect(self.tasks_tab.refresh_list) # Refresh tasks too just in case
        self.settings_tab.data_reset.connect(self.apply_theme)
        
        self.apply_theme()

    def apply_theme(self):
        from PySide6.QtCore import QSettings
        from PySide6.QtWidgets import QApplication
        from PySide6.QtGui import QColor
        
        settings = QSettings("FocusMate", "Settings")
        bg_color = settings.value("bg_color", "#0d1611")
        btn_color = settings.value("btn_color", "#00E676")
        
        base_btn = QColor(btn_color)
        hover_btn = base_btn.lighter(120).name()
        pressed_btn = base_btn.darker(110).name()
        
        stylesheet = f"""
            QMainWindow, QWidget {{
                background-color: {bg_color};
                color: #E0E0E0;
            }}
            QTabWidget::pane {{
                border: none;
            }}
            QTabBar::tab {{
                background: #15261F;
                color: #888;
                padding: 10px 16px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                margin-right: 2px;
                font-weight: bold;
            }}
            QTabBar::tab:selected {{
                background: {btn_color};
                color: #003300;
            }}
            
            /* Inputs & Lists */
            QLineEdit, QComboBox, QDateEdit, QListWidget, QTextEdit {{
                background-color: #1A2F25;
                color: white;
                border: 1px solid #2E5A3E;
                border-radius: 8px;
                padding: 8px;
                selection-background-color: {btn_color};
                selection-color: black;
            }}
            QListWidget::item {{
                padding: 5px;
            }}
            QListWidget::item:selected {{
                background-color: #2E5A3E;
                border-radius: 8px;
            }}

            /* Buttons */
            QPushButton {{
                background-color: {btn_color};
                color: #0b1410;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 14px;
            }}
            QPushButton:hover {{
                background-color: {hover_btn};
            }}
            QPushButton:pressed {{
                background-color: {pressed_btn};
            }}
            QPushButton:disabled {{
                background-color: #2E3E34;
                color: #555;
            }}
            
            /* Labels */
            QLabel {{
                color: #E0E0E0;
                background-color: transparent;
            }}
            
            /* Dialogs */
            QMessageBox {{
                background-color: #15261F;
            }}
            QMessageBox QPushButton {{
                width: 80px;
            }}
        """
        QApplication.instance().setStyleSheet(stylesheet)

    def switch_to_chatbot(self):
        """
        [AI DODATEK]: Preklopi na zavihek AI in pošlje 'stuck' sporočilo.
        To funkcijo kliče gumb 'I'm stuck' iz Focus zavihka.
        self.tabs.setCurrentWidget zamenja aktiven zavihek, nato pa trigger_stuck() 
        poskrbi za začetno interakcijo z umetno inteligenco (Groq).
        """
        self.tabs.setCurrentWidget(self.chatbot_tab)
        self.chatbot_tab.trigger_stuck()

    def closeEvent(self, event):
        """Ob zaprtju aplikacije."""
        self.focus_tab.save_state()
        event.accept()


if __name__ == "__main__":
    ensure_data_files()
    init_db()
    app = QApplication(sys.argv)
    
    # App stylesheet je sedaj nastavljen v apply_theme() metodi razreda MainWindow
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
