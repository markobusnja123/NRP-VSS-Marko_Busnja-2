@echo off
echo ===================================================
echo             FocusMate Startup
echo ===================================================

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to PATH. 
    echo Please install Python to run FocusMate.
    pause
    exit /b
)

:: Install dependencies globally
echo [INFO] Installing required dependencies (PySide6, groq)...
pip install -q PySide6 groq

:: Run the application
echo [INFO] Starting FocusMate...
python main.py
